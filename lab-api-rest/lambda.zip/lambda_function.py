import json
import base64

def _response(status_code, payload):
   return {
       "statusCode": status_code,
       "headers": {
           "Content-Type": "application/json"
       },
       "body": json.dumps(payload, ensure_ascii=False)
   }


def _parse_body(event):
   body = event.get("body")

   if body in (None, ""):
       raise ValueError("invalid body")

   if event.get("isBase64Encoded"):
       body = base64.b64decode(body).decode("utf-8")

   return json.loads(body)


def _extract_nombre(payload):
   nombre = payload.get("nombre")

   if not isinstance(nombre, str) or not nombre.strip():
       raise ValueError("invalid nombre")

   return nombre.strip()


def lambda_handler(event, context):
   resource = event.get("resource")
   method = event.get("httpMethod")

   if resource == "/saludar" and method == "POST":
       try:
           payload = _parse_body(event)
           nombre = _extract_nombre(payload)
       except (ValueError, TypeError, json.JSONDecodeError):
           return _response(400, {
               "error": "El nombre es obligatorio"
           })

       return _response(200, {
           "mensaje": f"Hola {nombre}, bienvenido a AWS Lambda"
       })

   return _response(200, {
       "message": "Laboratorio completado exitosamente"
   })
